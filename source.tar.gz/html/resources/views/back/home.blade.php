@extends('back.layout')

@section('title', trans('back.home.title'))

@section('breadcrumbs')
    <ol class="breadcrumb">
        <li class="active"><i class="fa fa-dashboard"></i> {{ trans('back.home.title') }}</li>
    </ol>
@endsection

@section('content')

    <?php if (Auth::user()->profile == 'administrador') : ?>

        <div class="col-lg-4">

            <!-- <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-users fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge" style="font-size: 40px;"><php echo count($proponentes); ?></div>
                            <div>Proponentes cadastrados</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer">
                    </div>
                </a>
            </div> -->

            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-folder-open-o" aria-hidden="true"></i> Quantidade de Proposta por Situação
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>Situação da Proposta</th>
                                        <th tyle="text-align: center;">Quantidade</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    @forelse ($records as $record)

                                        @if (empty($record->SITUACAO_PPST) || $record->SITUACAO_PPST > 11)
                                            @continue
                                        @endif

                                        <tr>
                                            <td>{{ \App\Models\Proposta::_SITUACAO_[$record->SITUACAO_PPST] }}</td>
                                            <td style="text-align: center;">{{ $record->quantidade }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4">{{ trans('back.common.records-not-found') }}</td>
                                        </tr>
                                    @endforelse

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.col-lg-4 (nested) -->
                        <div class="col-lg-8">

                        </div>
                        <!-- /.col-lg-8 (nested) -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.panel-body -->
            </div>

        </div>

    <?php else: ?>

        <div class="col-lg-4">

            <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-folder-open-o fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge" style="font-size: 40px;"><?php echo (isset($records[0])) ? $records[0]->quantidade : 0; ?></div>
                            <div><?php echo (isset($records[0]) && $records[0]->quantidade > 1) ? 'Propostas' : 'Proposta'; ?></div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer">
                    </div>
                </a>
            </div>

        </div>

    <?php endif; ?>


@endsection
