<footer class="main-footer">
    <div class="pull-right hidden-xs"><b>Version</b> 5.3</div>
    <strong>Copyright &copy; 2014 - {{ date('Y') }} <a href="mailto:renatotbueno@gmail.com">RTB Sistemas</a>.</strong> All rights reserved.
</footer>