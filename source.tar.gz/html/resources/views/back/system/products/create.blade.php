@extends('back.layout')

@section('title', trans('back.system.products.title'))

@section('breadcrumbs')
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> {{ trans('back.home.title') }}</a></li>
        <li><a href="/back/system">{{ trans('back.system.title') }}</a></li>
        <li><a href="/back/system/products">{{ trans('back.system.products.title') }}</a></li>
        <li class="active">{{ trans('back.common.add') }}</li>
    </ol>
@endsection

@section('content')
    <div class="text-right">
        <a href="/back/system/products" class="btn btn-default btn-flat margin-bottom">{{ trans('back.common.back') }}</a>
    </div>

    {!! Form::open(['method' => 'post', 'route' => ['products.store']]) !!}

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('back.system.products.create') }}</h3>
        </div>

        <div class="box-body">
            <div class="row">
            	<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    {!! Form::openGroup('title', trans('back.common.title'), ['class' => 'has-feedback']) !!}
                    {!! Form::text('title', null, ['placeholder' => trans('back.common.title')]) !!}
                    {!! Form::closeGroup() !!}
            	</div>

                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                    {!! Form::openGroup('price', trans('back.common.price'), ['class' => 'has-feedback']) !!}
                    {!! Form::text('price', null, ['placeholder' => trans('back.common.price')]) !!}
                    {!! Form::closeGroup() !!}
                </div>


            </div>

            <div class="row">

                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    {!! Form::openGroup('description', trans('back.common.description'), ['class' => 'has-feedback']) !!}
                    {!! Form::textarea('description', null, ['placeholder' => trans('back.common.description')]) !!}
                    {!! Form::closeGroup() !!}
                </div>

            </div>
        </div>

        <div class="box-footer clearfix">
            <button type="submit" class="btn btn-primary btn-flat">{{ trans('back.common.save') }}</button>
        </div>
    </div>

    {!! Form::close() !!}
@endsection
