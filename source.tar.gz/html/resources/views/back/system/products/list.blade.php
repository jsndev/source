@extends('back.layout')

@section('title', trans('back.system.products.title'))

@section('breadcrumbs')
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> {{ trans('back.home.title') }}</a></li>
        <li><a href="/back/system">{{ trans('back.system.title') }}</a></li>
        <li class="active">{{ trans('back.system.products.title') }}</li>
    </ol>
@endsection

@section('content')
    <div class="text-right">
        <a href="/back/system/products/create" class="btn btn-primary btn-flat margin-bottom">{{ trans('back.system.products.create') }}</a>
    </div>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('back.system.products.table') }}</h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="1%" nowrap>#</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th width="1%" nowrap>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($records as $record)
                        <tr>
                            <td>{{ $record->id }}</td>
                            <td>{{ $record->title }}</td>
                            <td>{{ $record->price }}</td>
                            <td nowrap>
                                <a href="/back/system/products/{{ $record->id }}/edit"><i class="fa fa-folder"></i> {{ trans('back.common.open') }}</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4">{{ trans('back.common.records-not-found') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="box-footer clearfix">
            {{ $records->links() }}
        </div>
    </div>
@endsection
