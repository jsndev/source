@extends('back.layout')

@section('title', trans('back.system.proposta.historico') . ' de ' . trans('back.system.proposta.title'))

@section('breadcrumbs')
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> {{ trans('back.home.title') }}</a></li>
        <li><a href="/back">{{ trans('back.system.title') }}</a></li>
        <li><a href="/back/system/propostas">{{ trans('back.system.proposta.title') }}</a></li>
        <li class="active">{{ trans('back.system.proposta.historico') }}</li>
    </ol>
@endsection

@section('content')

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">{{ trans('back.system.proposta.historico') }}</h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="1%" nowrap>Código da Proposta: <span style="font-size: 16px;">{{ $cod_proposta }}</span></th>
                    </tr>
                </thead>
            </table>
        </div>

        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="160">Data</th>
                        <th width="500">Observação</th>
                        <th width="300">Arquivo</th>
                        <th width="130">Apto</th>
                        <th width="160">Usuário</th>
                    </tr>
                </thead>
                <tbody>
                @forelse ($records as $record)

                    <tr>
                        <?php if (!empty($record->DT_HIST)) : ?>
                            <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $record->DT_HIST)->format('d/m/Y H:i:s') ?></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <td>{{ $record->OBS_HIST }}</td>
                        <td><a href="http://localhost:8080/upload/analises/{{ $record->PATH_ARQUIVO_ANEXO }}" download>{{ $record->ARQUIVO_ANEXO }}</a></td>
                        <td>
                            @if ($record->APTO == 'SIM')
                                Sim
                            @elseif ($record->APTO == 'NAO')
                                Não
                            @else
                                Não informado
                            @endif
                        </td>
                        <td>{{ $record->NOME_USUA }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4">{{ trans('back.common.records-not-found') }}</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
        <div class="box-footer clearfix">
            {{ $records->links() }}
        </div>
    </div>

    <button class="btn btn-info" onclick="window.history.back()">Voltar</button>
@endsection
