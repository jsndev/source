@extends('back.layout')

@section('title', 'Documentos da Proposta')

@section('breadcrumbs')
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> {{ trans('back.home.title') }}</a></li>
        <li><a href="/back">{{ trans('back.system.title') }}</a></li>
        <li><a href="/back/system/propostas">{{ trans('back.system.proposta.title') }}</a></li>
        <li class="active">Documentos</li>
    </ol>
@endsection

@section('content')

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Documentos</h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="1%" nowrap>Código da Proposta: <span style="font-size: 16px;">{{ $cod_proposta }}</span></th>
                    </tr>
                </thead>
            </table>
        </div>

        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="160">Data</th>
                        <th width="300">Tipo</th>
                        <th width="300">Sub-Tipo</th>
                        <th width="400">Arquivo</th>
                        <th width="160">Usuário</th>
                    </tr>
                </thead>
                <tbody>
                @forelse ($records as $record)

                    <?php
                        $tipo = $record->tipo;
                        if (!empty($record->parent_id) && $record->parent_id == 4) {
                            $tipo = 'Vendedor > ' . $tipo;
                        }
                    ?>

                    <tr>
                        <?php if (!empty($record->data_criacao)) : ?>
                            <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $record->data_criacao)->format('d/m/Y H:i:s') ?></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <td>{{ $tipo }}</td>
                        <td>{{ $record->subtipo }}</td>
                        <td><a href="http://carim.ddns.net:8084/upload/documentos/{{ $record->hash_arquivo }}" download>{{ $record->nome_arquivo }}</a></td>
                        <td>{{ $record->nome_usuario }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4">{{ trans('back.common.records-not-found') }}</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
        <div class="box-footer clearfix">
            {{ $records->links() }}
        </div>
    </div>

    <button class="btn btn-info" onclick="window.history.back()">Voltar</button>
@endsection
