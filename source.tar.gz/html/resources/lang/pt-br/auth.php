<?php

return [
    'failed' => 'Credenciais não encontradas.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',

    'login' => [
        'title' => 'Faça o login para iniciar a sessão',
        'membership' => 'Já possuo cadastro',
        'submit' => 'Entrar',
    ],

    'forgot' => [
        'title' => 'Esqueci minha senha',
        'submit' => 'Enviar',
    ],

    'register' => [
        'title' => 'Criar usuário de acesso',
        'confirmation' => 'Confirme a senha',
        'terms' => 'I agree to the <a href=":link">terms</a>',
        'submit' => 'Salvar',
    ],

    'reset' => [
        'title' => 'Resetar a Senha',
        'submit' => 'Resetar a Senha',
    ],
];
