<?php

return [

    'email' => 'Endereço de Email',
    'password' => 'Senha',
    'sign-in' => 'Entrar',
    'sign-out' => 'Sair',
    'profile' => 'Perfil',
    'remember' => 'Lembre-me',
    'register' => 'Registrar',
    'full-name' => 'Nome completo',
    'cpf' => 'CPF',

];
