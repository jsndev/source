<?php

return [
    'common' => [
        'records-not-found' => 'Nenhum registro encontrado.',
        'search' => 'Pesquisar',
        'open' => 'Abrir',
        'since' => 'Desde',
        'back' => 'Voltar',
        'add' => 'Adicionar',
        'name' => 'Nome',
        'email' => 'Email',
        'password' => 'Senha',
        'save' => 'Salvar',
        'remove' => 'Remover',
        'edit' => 'Editar',
        'success' => 'Operação efetuada com sucesso',
        'title' => 'Titulo',
        'description' => 'Descrição',
        'price' => 'Preço',
        'cpf' => 'CPF',
        'view' => 'Visualizar',
    ],
    'header' => [
        'toggle' => 'Toggle navigation'
    ],
    'aside' => [
        'title' => 'Navegação principal',
    ],
    'home' => [
        'title' => 'Dashboard',
        'propostas' => 'Propostas'
    ],
    'system' => [
        'title' => 'Sistema',
        'users' => [
            'title' => 'Usuários',
            'table' => 'Lista de usuários',
            'create' => 'Criar novo usuário',
            'edit' => 'Editar usuário :name <:email>',
        ],
        'products' => [
            'title' => 'Produtos',
            'table' => 'Lista de Produtos',
            'create' => 'Criar novo Produtos',
            'edit' => 'Editar produto :title',
        ],
        'proposta' => [
            'title' => 'Propostas',
            'table' => 'Lista de Propostas',
            'historico' => 'Histórico'
        ]

    ]
];