<?php

return [
    'common' => [
        'records-not-found' => 'Records not found.',
        'search' => 'Search',
        'open' => 'Open',
        'since' => 'Since',
        'back' => 'Back',
        'add' => 'Add',
        'name' => 'Name',
        'email' => 'Email',
        'password' => 'Password',
        'save' => 'Save',
        'remove' => 'Remove',
        'edit' => 'Edit',
        'success' => 'Operation has been successful',
        'title' => 'Title',
        'description' => 'Description',
        'price' => 'Price',
        'cpf' => 'CPF',
        'view' => 'Visualizar',
    ],
    'header' => [
        'toggle' => 'Toggle navigation'
    ],
    'aside' => [
        'title' => 'main navigation',
    ],
    'home' => [
        'title' => 'Dashboard',
        'propostas' => 'Propostas'
    ],
    'system' => [
        'title' => 'System',
        'users' => [
            'title' => 'Users',
            'table' => 'List of users',
            'create' => 'Create new user',
            'edit' => 'Edit user :name <:email>',
        ],
        'products' => [
            'title' => 'Products',
            'table' => 'List of products',
            'create' => 'Create new proruct',
            'edit' => 'Edit product :title',
        ],
        'proposta' => [
            'title' => 'Propostas',
            'table' => 'Lista de Propostas',
            'historico' => 'Histórico'
        ]

    ]
];