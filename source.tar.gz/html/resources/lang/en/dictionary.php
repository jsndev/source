<?php

return [

    'email' => 'Email Address',
    'password' => 'Password',
    'sign-in' => 'Sign In',
    'sign-out' => 'Sign Out',
    'profile' => 'Profile',
    'remember' => 'Remember',
    'register' => 'Register',
    'full-name' => 'Full Name',
    'cpf' => 'CPF',

];
