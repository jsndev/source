<?php $__env->startSection('title', trans('back.home.title')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <ol class="breadcrumb">
        <li class="active"><i class="fa fa-dashboard"></i> <?php echo e(trans('back.home.title')); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if (Auth::user()->profile == 'administrador') : ?>

        <div class="col-lg-4">

            <!-- <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-users fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge" style="font-size: 40px;"><php echo count($proponentes); ?></div>
                            <div>Proponentes cadastrados</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer">
                    </div>
                </a>
            </div> -->

            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-folder-open-o" aria-hidden="true"></i> Quantidade de Proposta por Situação
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>Situação da Proposta</th>
                                        <th tyle="text-align: center;">Quantidade</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>

                                        <?php if(empty($record->SITUACAO_PPST) || $record->SITUACAO_PPST > 11): ?>
                                            <?php continue; ?>
                                        <?php endif; ?>

                                        <tr>
                                            <td><?php echo e(\App\Models\Proposta::_SITUACAO_[$record->SITUACAO_PPST]); ?></td>
                                            <td style="text-align: center;"><?php echo e($record->quantidade); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4"><?php echo e(trans('back.common.records-not-found')); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.col-lg-4 (nested) -->
                        <div class="col-lg-8">

                        </div>
                        <!-- /.col-lg-8 (nested) -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.panel-body -->
            </div>

        </div>

    <?php else: ?>

        <div class="col-lg-4">

            <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-folder-open-o fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge" style="font-size: 40px;"><?php echo (isset($records[0])) ? $records[0]->quantidade : 0; ?></div>
                            <div><?php echo (isset($records[0]) && $records[0]->quantidade > 1) ? 'Propostas' : 'Proposta'; ?></div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer">
                    </div>
                </a>
            </div>

        </div>

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>