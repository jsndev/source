<?php $__env->startSection('title', trans('back.system.proposta.title')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> <?php echo e(trans('back.home.title')); ?></a></li>
        <li><a href="/back"><?php echo e(trans('back.system.title')); ?></a></li>
        <li class="active"><?php echo e(trans('back.system.proposta.title')); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('back.system.proposta.table')); ?></h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="1%" nowrap>Código</th>
                        <th>Data Criação</th>
                        <th>Valor</th>
                        <th>Situação</th>
                        <th width="1%" nowrap>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($record->COD_PPST); ?></td>
                            <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d', $record->DATA_PPST)->format('d/m/Y') ?></td>
                            <td>R$ <?php echo number_format($record->VALORSEGURO_PPST, 2, ',', '.'); ?></td>
                            <?php $record->SITUACAO_PPST = ($record->SITUACAO_PPST > 11) ? 0 : $record->SITUACAO_PPST; ?>
                            <td><?php echo e(\App\Models\Proposta::_SITUACAO_[$record->SITUACAO_PPST]); ?></td>
                            <td nowrap>
                                <a href="/back/system/propostas/<?php echo e($record->COD_PPST); ?>"><i class="fa fa-folder"></i> <?php echo e(trans('back.common.view')); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4"><?php echo e(trans('back.common.records-not-found')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="box-footer clearfix">
            <?php echo e($records->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>