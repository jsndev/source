<header class="main-header">
    <a href="/back" class="logo">
        <span class="logo-mini"><b>A</b>G</span>
        <span class="logo-lg"><b>Athos</b>Gestão</span>
    </a>

    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only"><?php echo e(trans('back.header.toggle')); ?></span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(Gravatar::src(Auth::user()->email, 25)); ?>" class="user-image" alt="<?php echo e(Auth::user()->name); ?>">
                        <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                    </a>

                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <img src="<?php echo e(Gravatar::src(Auth::user()->email, 160)); ?>" class="img-circle" alt="<?php echo e(Auth::user()->name); ?>">

                            <p>
                                <?php echo e(Auth::user()->name); ?>

                                <small>Membro desde <?php echo e(Auth::user()->created_at->format('m/Y')); ?></small>
                            </p>
                        </li>

                        <li class="user-footer">
                            
                                
                            
                            <div class="pull-right">
                                <a href="/logout" class="btn btn-default btn-flat"><?php echo e(trans('dictionary.sign-out')); ?></a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>