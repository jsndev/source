﻿

<?php $__env->startSection('title', trans('back.system.proposta.title')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> <?php echo e(trans('back.home.title')); ?></a></li>
        <li><a href="/back"><?php echo e(trans('back.system.title')); ?></a></li>
        <li class="active"><?php echo e(trans('back.system.proposta.title')); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <script>

        jQuery(function(){

            $(".somentenumero").bind("keyup blur focus", function(e) {
                e.preventDefault();
                var expre = /[^\d]/g;
                $(this).val($(this).val().replace(expre,''));
            });

            jQuery('#btnPesquisar').click(function(){
                jQuery('#exportar').val('nao');
                jQuery('#pesquisar').submit();
            });

            jQuery('#btnExportar').click(function(){
                jQuery('#exportar').val('sim');
                jQuery(this).text('Gerando arquivo... essa ação pode durar algum tempo...');
                jQuery('#pesquisar').submit();

                setTimeout(function(){
                    jQuery('#btnExportar').text('Exportar resultado');
                }, 3000)
            })

        })

    </script>

    <?php if (Auth::user()->profile == 'administrador') : ?>


        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Filtros</h3>
            </div>

            <form action="/back/system/propostas" method="GET" name="pesquisar" id="pesquisar">
                <input type="hidden" name="exportar" id="exportar" value="nao" />
                <div class="box-body">

                    <div class="row">
                        <div class="col-lg-3">
                            Código Identificador
                            <input type="text" class="form-control somentenumero" placeholder="Matrícula" name="id_lstn" value="<?php echo (isset($_GET['id_lstn']) ? $_GET['id_lstn'] : null) ?>"/>
                        </div>

                        <div class="col-lg-3">
                            CPF
                            <input type="text" class="form-control somentenumero" placeholder="CPF" id="cpf" name="cpf" value="<?php echo (isset($_GET['cpf']) ? $_GET['cpf'] : null)?>"/>
                        </div>

                        <div class="col-lg-3">
                            Nome
                            <input type="text" class="form-control" placeholder="Nome" name="nome" value="<?php echo (isset($_GET['nome']) ? $_GET['nome'] : null)?>"/>
                        </div>

                    </div>

                </div>

                <div class="box-footer">
                    <button class="btn btn-success" id="btnPesquisar">Pesquisar</button>
                    <button class="btn btn-primary" id="btnExportar" <?php echo ($liberaBotaoExportar) ? '' : 'disabled' ?>>
                        Exportar resultado
                    </button>
                    <?php if (!$liberaBotaoExportar) :?>
                    <span class="label label-info"><i class="fa fa-info-circle" aria-hidden="true"></i> Preencha ao menos um filtro para exportar.</span>
                    <?php endif; ?>
                </div>
            </form>
        </div>

    <?php endif; ?>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('back.system.proposta.table')); ?></h3>
        </div>

        <div class="box-body">

            <?php if (Auth::user()->profile == 'administrador') : ?>

                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th width="1%" nowrap>Código da Proposta</th>
                        <th width="1%" nowrap>Código Identificador</th>
                        <th width="5%" nowrap>Proponente</th>
                        <th width="5%" nowrap>CPF Proponente</th>
                        <th width="5%">Data Criação</th>
                        <th width="5%">Valor</th>
                        <th width="5%">Situação</th>
                        <th width="1%" nowrap>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($record->COD_PPST); ?></td>
                            <td><?php echo e($record->ID_LSTN); ?></td>
                            <td><?php echo e($record->NOME_USUA); ?></td>
                            <td><?php echo e($record->CPF_PPNT); ?></td>
                            <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d', $record->DATA_PPST)->format('d/m/Y') ?></td>
                            <td>R$ <?php echo number_format($record->VLFINSOL_PPNT, 2, ',', '.'); ?></td>
                            <?php $record->SITUACAO_PPST = ($record->SITUACAO_PPST > 11) ? 0 : $record->SITUACAO_PPST; ?>
                            <td><?php echo e(\App\Models\Proposta::_SITUACAO_[$record->SITUACAO_PPST]); ?></td>
                            <td nowrap>
                                <a href="/back/system/proposta/<?php echo e($record->COD_PPST); ?>/historico"><span class="label label-info">Ver Histórico</span></a>
                                <a href="/back/system/proposta/<?php echo e($record->COD_PPST); ?>/documentos"><span class="label label-default">Ver Documentos</span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8"><?php echo e(trans('back.common.records-not-found')); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>

            <?php else: ?>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th width="1%" nowrap>Código da Proposta</th>
                            <th width="1%" nowrap>Código Identificador</th>
                            <th>Data Criação</th>
                            <th>Valor</th>
                            <th>Situação</th>
                            <th width="1%" nowrap>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($record->COD_PPST); ?></td>
                                <td><?php echo e(isset($record->ID_LSTN) ? $record->ID_LSTN : ''); ?></td>
                                <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d', $record->DATA_PPST)->format('d/m/Y') ?></td>
                                <td>R$ <?php echo number_format($record->VLFINSOL_PPNT, 2, ',', '.'); ?></td>
                                <?php $record->SITUACAO_PPST = ($record->SITUACAO_PPST > 11) ? 0 : $record->SITUACAO_PPST; ?>
                                <td><?php echo e(\App\Models\Proposta::_SITUACAO_[$record->SITUACAO_PPST]); ?></td>
                                <td nowrap>
                                    <a href="/back/system/proposta/<?php echo e($record->COD_PPST); ?>/historico"><span class="label label-info">Ver Histórico</span></a>
                                    <a href="/back/system/proposta/<?php echo e($record->COD_PPST); ?>/documentos"><span class="label label-default">Ver Documentos</span></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6"><?php echo e(trans('back.common.records-not-found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            <?php endif; ?>
        </div>
        <div class="box-footer clearfix">
            <?php echo e($records->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>