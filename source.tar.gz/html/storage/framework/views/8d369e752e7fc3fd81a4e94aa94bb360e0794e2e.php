<?php $__env->startSection('content'); ?>

    <script>
        function somenteNumeros(num) {
            var er = /[^0-9.]/;
            er.lastIndex = 0;
            var campo = num;
            if (er.test(campo.value)) {
                campo.value = "";
            }
        }
    </script>

    <div class="register-box-body">
        <p class="login-box-msg"><?php echo e(trans('auth.register.title')); ?></p>

        <?php echo Form::open(); ?>


        <?php echo Form::openGroup('name', null, ['class' => 'has-feedback']); ?>

        <?php echo Form::text('name', null, ['placeholder' => trans('dictionary.full-name')]); ?>

        <span class="glyphicon glyphicon-user form-control-feedback"></span>
        <?php echo Form::closeGroup(); ?>


        <?php echo Form::openGroup('cpf', null, ['class' => 'has-feedback']); ?>

        <?php echo Form::text('cpf', null, ['placeholder' => trans('dictionary.cpf'), 'onKeyPress' => "somenteNumeros(this);", 'onKeyDown' => "somenteNumeros(this);", 'onKeyUp' => "somenteNumeros(this);", 'onBlur' => "somenteNumeros(this);", 'maxlength' => 11]); ?>

        <span class="glyphicon glyphicon-user form-control-feedback"></span>
        <?php echo Form::closeGroup(); ?>


        <?php echo Form::openGroup('email', null, ['class' => 'has-feedback']); ?>

        <?php echo Form::email('email', null, ['placeholder' => trans('dictionary.email')]); ?>

        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <?php echo Form::closeGroup(); ?>


        <?php echo Form::openGroup('password', null, ['class' => 'has-feedback']); ?>

        <?php echo Form::password('password', ['placeholder' => trans('dictionary.password')]); ?>

        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <?php echo Form::closeGroup(); ?>


        <?php echo Form::openGroup('password_confirmation', null, ['class' => 'has-feedback']); ?>

        <?php echo Form::password('password_confirmation', ['placeholder' => trans('auth.register.confirmation')]); ?>

        <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
        <?php echo Form::closeGroup(); ?>


        <div class="row">
            <div class="col-xs-4">
                <button type="submit" class="btn btn-primary btn-block btn-flat"><?php echo e(trans('auth.register.submit')); ?></button>
            </div>
        </div>
        <?php echo Form::close(); ?>


        <hr />

        <a href="/login" class="text-center"><?php echo e(trans('auth.login.membership')); ?></a>
    </div>
    <!--
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Register</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Name</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
        <span class="help-block">
        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                    <?php if($errors->has('email')): ?>
        <span class="help-block">
        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
            </div>
        </div>

        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
        <span class="help-block">
        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

            <div class="col-md-6">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Register
                </button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</div>
-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>