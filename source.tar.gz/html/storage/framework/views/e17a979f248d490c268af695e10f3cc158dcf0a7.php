<?php $__env->startSection('title', 'Documentos da Proposta'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> <?php echo e(trans('back.home.title')); ?></a></li>
        <li><a href="/back"><?php echo e(trans('back.system.title')); ?></a></li>
        <li><a href="/back/system/propostas"><?php echo e(trans('back.system.proposta.title')); ?></a></li>
        <li class="active">Documentos</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Documentos</h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="1%" nowrap>Código da Proposta: <span style="font-size: 16px;"><?php echo e($cod_proposta); ?></span></th>
                    </tr>
                </thead>
            </table>
        </div>

        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="160">Data</th>
                        <th width="300">Tipo</th>
                        <th width="300">Sub-Tipo</th>
                        <th width="400">Arquivo</th>
                        <th width="160">Usuário</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>

                    <?php
                        $tipo = $record->tipo;
                        if (!empty($record->parent_id) && $record->parent_id == 4) {
                            $tipo = 'Vendedor > ' . $tipo;
                        }
                    ?>

                    <tr>
                        <?php if (!empty($record->data_criacao)) : ?>
                            <td><?php echo \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $record->data_criacao)->format('d/m/Y H:i:s') ?></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <td><?php echo e($tipo); ?></td>
                        <td><?php echo e($record->subtipo); ?></td>
                        <td><a href="http://carim.ddns.net:8084/upload/documentos/<?php echo e($record->hash_arquivo); ?>" download><?php echo e($record->nome_arquivo); ?></a></td>
                        <td><?php echo e($record->nome_usuario); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4"><?php echo e(trans('back.common.records-not-found')); ?></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="box-footer clearfix">
            <?php echo e($records->links()); ?>

        </div>
    </div>

    <button class="btn btn-info" onclick="window.history.back()">Voltar</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>