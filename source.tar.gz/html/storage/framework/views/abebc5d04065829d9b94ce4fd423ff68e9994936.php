<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(Gravatar::src(Auth::user()->email, 45)); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->name); ?></p>
                <a href="#"><?php echo e(trans('back.common.since')); ?> <?php echo e(Auth::user()->created_at->format('d/m/Y')); ?></a>
            </div>
        </div>

        <ul class="sidebar-menu">
            <li class="header"><?php echo e(strtoupper(trans('back.aside.title'))); ?></li>
            <li>
                <a href="/back">
                    <i class="fa fa-dashboard"></i>
                    <span><?php echo e(trans('back.home.title')); ?></span>
                </a>
            </li>
            <li>
                <a href="/back/system/propostas">
                    <i class="fa fa-folder"></i>
                    <span><?php echo e(trans('back.home.propostas')); ?></span>
                </a>
            </li>
            
                
                    
                    
                    
                
                
                    
                    
                
            
        </ul>
    </section>
</aside>