<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(Session::has('message') && Session::get('message-class')): ?>
    <div class="alert alert-<?php echo Session::get('message-class'); ?>">
        <p><?php echo e(Session::get('message')); ?></p>
    </div>
<?php endif; ?>