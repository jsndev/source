<?php $__env->startSection('title', trans('back.system.users.title')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <ol class="breadcrumb">
        <li><a href="/back"><i class="fa fa-dashboard"></i> <?php echo e(trans('back.home.title')); ?></a></li>
        <li><a href="/back/system"><?php echo e(trans('back.system.title')); ?></a></li>
        <li><a href="/back/system/users"><?php echo e(trans('back.system.users.title')); ?></a></li>
        <li class="active"><?php echo e(trans('back.common.edit')); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-right">
        <a href="/back/system/users" class="btn btn-default btn-flat margin-bottom"><?php echo e(trans('back.common.back')); ?></a>
    </div>

    <?php echo Form::model($record, ['route' => ['users.update', $record->id], 'method' => 'put']); ?>


    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('back.system.users.edit', $record->toArray())); ?></h3>
        </div>

        <div class="box-body">
            <div class="row">
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">

                    <?php echo Form::openGroup('name', trans('back.common.name'), ['class' => 'has-feedback']); ?>

                    <?php echo Form::text('name', null, ['placeholder' => trans('back.common.name')]); ?>

                    <?php echo Form::closeGroup(); ?>


                    <?php echo Form::openGroup('email', trans('back.common.email'), ['class' => 'has-feedback']); ?>

                    <?php echo Form::email('email', null, ['placeholder' => trans('back.common.email')]); ?>

                    <?php echo Form::closeGroup(); ?>


                    <?php echo Form::openGroup('cpf', trans('back.common.cpf'), ['class' => 'has-feedback']); ?>

                    <?php echo Form::text('cpf', null, ['placeholder' => trans('back.common.cpf'), 'disabled' => 'disabled']); ?>

                    <?php echo Form::closeGroup(); ?>


                    <?php echo Form::openGroup('password', trans('back.common.password'), ['class' => 'has-feedback']); ?>

                    <?php echo Form::password('password', ['placeholder' => trans('back.common.password')]); ?>

                    <?php echo Form::closeGroup(); ?>

                </div>

            </div>
        </div>

        <div class="box-footer clearfix">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <button type="submit" class="btn btn-primary btn-flat"><?php echo e(trans('back.common.save')); ?></button>
                    <?php echo Form::close(); ?>

                </div>

                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right">
                    <?php echo Form::open(['method' => 'delete', 'data-confirm' => 'You will not be able to recover this record!', 'route' => ['users.destroy', $record->id]]); ?>

                    <?php echo Form::button(trans('back.common.remove'), ['type' => 'submit', 'class' => 'btn btn-danger btn-flat']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>