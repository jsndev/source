<?php

namespace App\Http\Controllers\Back;

use App\Http\Controllers\Controller;
use \DB;
use \Auth;

class DashboardController extends Controller
{
    public function index()
    {

		if (Auth::user()->profile == 'administrador') {

			$records = DB::table('proposta')
				->select(DB::raw('count(*) as quantidade, SITUACAO_PPST'))
				->groupBy('SITUACAO_PPST')
				->get();

			$proponentes = DB::table('proponente')
				->join('usuario', 'usuario.COD_USUA', '=', 'proponente.COD_PROPONENTE')
				->select(DB::raw('count(*) as quantidade'))
				->where('usuario.ativo', 1)
				->groupBy('CPF_PPNT')
				->get();

			return view('back.home', ['records' => $records, 'proponentes' => $proponentes]);

		} else {

			$proponentes = null;
			$records = DB::table('proponente')
				->join('users', 'users.cpf', '=', 'proponente.CPF_PPNT')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->where('users.cpf', Auth::user()->cpf)
				->select(DB::raw('count(*) as quantidade'))
				->groupBy('SITUACAO_PPST')
				->get();

			return view('back.home', ['records' => $records]);
		}

    }
}
