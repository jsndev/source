<?php

namespace App\Http\Controllers\Back\System;

use App\Http\Controllers\Controller;
use App\Http\Requests\Back\ProductRequest;
use App\Models\Product;
use App\Models\User;
use App\Services\Products\CreateProduct;
use App\Services\Products\EditProduct;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $records = Product::paginate();

        return view('back.system.products.list', ['records' => $records]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('back.system.products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param UserRequest $request
     * @param CreateUser $createUser
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request, CreateProduct $createProduct)
    {
        if ($createProduct->execute($request->all())) {
            return $this->goToProducts(trans('back.common.success'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::find($id);

        return view('back.system.products.edit', ['record' => $product]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UserRequest $request
     * @param EditUser $editUser
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProductRequest $request, EditProduct $editProduct, $id)
    {
        if ($editProduct->execute($id, $request->all())) {
            return $this->goToProducts(trans('back.common.success'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::find($id);

        if ($product->delete()) {
            return $this->goToProducts(trans('back.common.success'));
        }
    }

    /**
     * @param null $message
     * @param string $type
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    private function goToProducts($message = null, $type = 'info')
    {
        if ($message) {
            flash($message, $type);
        }

        return redirect('/back/system/products');
    }
}
