<?php

namespace App\Http\Controllers\Back\System;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PropostasController extends Controller
{

    public function index(Request $request)
    {
		$liberaBotaoExportar = false;

		if (Auth::user()->profile == 'administrador') {

			$id_lstn 	= ($request->input('id_lstn') != null) ? $request->input('id_lstn') : null;
			$cpf 		= ($request->input('cpf') != null) ? $request->input('cpf') : null;
			$nome 		= ($request->input('nome') != null) ? $request->input('nome') : null;

			$records = DB::table('proponente')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->join('imovel', 'proposta.COD_PPST', '=', 'imovel.COD_PPST')
				->join('usuario', 'usuario.COD_USUA', '=', 'proponente.COD_PROPONENTE')
				->whereNotNull('usuario.NOME_USUA')
				->where('proposta.SITUACAO_PPST', '>', 0)
				->where('proposta.SITUACAO_PPST', '<', 12);

			if (!empty($id_lstn)) {
				$liberaBotaoExportar = true;
				$records->where('usuario.ID_LSTN', $id_lstn);
			}

			if (!empty($cpf)) {
				$liberaBotaoExportar = true;
				$cpf = preg_replace("/[^0-9]/", '', $cpf);
				$records->where('proponente.CPF_PPNT', $cpf);
			}

			if (!empty($nome)) {
				$liberaBotaoExportar = true;
				$records->where('usuario.NOME_USUA', 'like',  "%$nome%");
			}

			$records->where('proposta.FLGPROPOSTAATIVA_PPST', 1);

			if ($request->input('exportar') == 'sim') {
				$records = $records->get();
				$this->exportar($records);
			} else {
				$records = $records->paginate(50);
			}

		} else {

			$records = DB::table('proponente')
				->join('users', 'users.cpf', '=', 'proponente.CPF_PPNT')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->where('users.cpf', Auth::user()->cpf)
				->paginate(10);

		}

        return view('back.system.propostas.list', ['records' => $records, 'liberaBotaoExportar' => $liberaBotaoExportar]);
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * Exibe o historico das propostas de acordo com o proponente logado e a proposta selecionada
     */
    public function exibirHistorico($id)
    {

		if (Auth::user()->profile == 'administrador') {

			$records = DB::table('proponente')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->join('historico', 'proposta.COD_PPST', '=', 'historico.COD_PPST')
				->join('usuario', 'usuario.COD_USUA', '=', 'historico.COD_USUA')
				->where('proposta.COD_PPST', $id)
				->whereNotNull('historico.COD_USUA')
				->orderBy('historico.DT_HIST', 'desc')
				->paginate(10);

		} else {

			$records = DB::table('proponente')
				->join('users', 'users.cpf', '=', 'proponente.CPF_PPNT')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->join('historico', 'proposta.COD_PPST', '=', 'historico.COD_PPST')
				->join('usuario', 'usuario.COD_USUA', '=', 'historico.COD_USUA')
				->where('users.cpf', Auth::user()->cpf)
				->where('proposta.COD_PPST', $id)
				->whereNotNull('historico.COD_USUA')
				->orderBy('historico.DT_HIST', 'desc')
				->paginate(10);

		}


        return view('back.system.propostas.viewhistorico', ['records' => $records, 'cod_proposta' => $id]);
    }

	/**
	 * @param $id
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 * Exibe o historico das propostas de acordo com o proponente logado e a proposta selecionada
	 */
	public function exibirDocumentos($id)
	{

		if (Auth::user()->profile == 'administrador') {

			$records = DB::table('proponente')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->join('documentos_anexo', 'documentos_anexo.cod_proposta', '=', 'proposta.COD_PPST')
				->join('usuario', 'usuario.COD_USUA', '=', 'documentos_anexo.cod_usuario')
				->join('tipo_documentacao', 'tipo_documentacao.id', '=', 'documentos_anexo.tipo')
				->join('subtipo_documentacao', 'subtipo_documentacao.id', '=', 'documentos_anexo.subtipo')
				->where('proposta.COD_PPST', $id)
				->orderBy('documentos_anexo.data_criacao', 'desc')
				->select(
					'cod_proposta',
					'usuario.nome_usua as nome_usuario',
					'hash_arquivo',
					'nome_arquivo',
					'tipo_documentacao.id as id_tipo',
					'tipo_documentacao.descricao as tipo',
					'tipo_documentacao.parent_id as parent_id',
					'subtipo_documentacao.descricao as id_subtipo',
					'subtipo_documentacao.descricao as subtipo',
					'documentos_anexo.data_criacao'
				)
				->paginate(10);

		} else {

			$records = DB::table('proponente')
				->join('users', 'users.cpf', '=', 'proponente.CPF_PPNT')
				->join('proposta', 'proposta.COD_PPST', '=', 'proponente.COD_PPST')
				->join('documentos_anexo', 'documentos_anexo.cod_proposta', '=', 'proposta.COD_PPST')
				->join('tipo_documentacao', 'tipo_documentacao.id', '=', 'documentos_anexo.tipo')
				->join('subtipo_documentacao', 'subtipo_documentacao.id', '=', 'documentos_anexo.subtipo')
				->join('usuario', 'usuario.COD_USUA', '=', 'documentos_anexo.cod_usuario')
				->where('users.cpf', Auth::user()->cpf)
				->where('proposta.COD_PPST', $id)
				->orderBy('documentos_anexo.data_criacao', 'desc')
				->select(
					'cod_proposta',
					'usuario.nome_usua as nome_usuario', 
					'hash_arquivo', 
					'nome_arquivo',
					'tipo_documentacao.id as id_tipo',
					'tipo_documentacao.descricao as tipo',
					'tipo_documentacao.parent_id as parent_id',
					'subtipo_documentacao.descricao as id_subtipo',
					'subtipo_documentacao.descricao as subtipo',
					'documentos_anexo.data_criacao'
				)
				->paginate(10);

		}


		return view('back.system.propostas.viewdocumentos', ['records' => $records, 'cod_proposta' => $id]);
	}

	public function exportar($records)
	{


//
//		dd($records);

		// Definimos o nome do arquivo que será exportado
		$arquivo = 'planilha.xls';
		// Criamos uma tabela HTML com o formato da planilha
		$html = '';
		$html .= '<table border="1">';
		$html .= '<tr>';
			$html .= '<td><b>Matricula</b></td>';
			$html .= '<td><b>CPF</b></td>';
			$html .= '<td><b>Nome</b></td>';
			$html .= '<td><b>Valor de Compra</b></td>';
			$html .= '<td><b>Valor de Entrada</b></td>';
			$html .= '<td><b>Valor do FGTS</b></td>';
			$html .= '<td><b>Valor de Sinal</b></td>';
			$html .= '<td><b>Valor do Financiamento</b></td>';
			$html .= '<td><b>Valor da Prestacao</b></td>';
			$html .= '<td><b>Prazo</b></td>';
			$html .= '<td><b>Data de Abertura da Pasta no Sistema</b></td>';
			$html .= '<td><b>Data de Recebimento da Documentacao para Avaliacao</b></td>';
			$html .= '<td><b>Data de Solicitacao da Avaliacao</b></td>';
			$html .= '<td><b>Data de Envio do Email de 2o Contato com o Valor da Avaliacao</b></td>';
			$html .= '<td><b>Recebimento da Documentacao de 2a Fase</b></td>';
			$html .= '<td><b>Data de Envio da Analise Juridica</b></td>';
			$html .= '<td><b>Data de Recebimento da Documentacao Faltante</b></td>';
			$html .= '<td><b>Data Apto</b></td>';
			$html .= '<td><b>Data de Operacionalizacao da Proposta</b></td>';
			$html .= '<td><b>Aprovacao do Imovel</b></td>';
			$html .= '<td><b>Aprovacao da Proposta</b></td>';
			$html .= '<td><b>Emissao do Contrato</b></td>';
		$html .= '</tr>';


		if ( $records ) {

			foreach ( $records as $record ) {

				$recebimentoDocumentacaoAvaliacao 	= $this->getHistorico($record->COD_PPST, 1); //1	Recebida documentação para a avaliação
				$solicitacaoAvaliacao 			 	= $this->getHistorico($record->COD_PPST, 3); //3	Solicitada avaliação do imóvel
				$envioEmail2ContatoValorAvaliacao 	= $this->getHistorico($record->COD_PPST, 4); //4	Encaminhado e-mail de 2º contato ao proponente
				$recebimentoDocumentacao2Fase 		= $this->getHistorico($record->COD_PPST, 5); //5	Recebida documentação de 2ª fase com prazo para an
				$envioAnaliseJuridica 				= $this->getHistorico($record->COD_PPST, 6); //6	Analise Jurídica efetuada
				$recebimentoDocumentacaoFaltante 	= $this->getHistorico($record->COD_PPST, 9); //9	Recebida documentação faltante. Prazo para análise
				$dataApto 							= $this->getHistorico($record->COD_PPST, 7); //7	Encaminhado e-mail de apto. Segue para operacional
				$operacionalizacaoProposta 			= $this->getHistorico($record->COD_PPST, 10); //10	Proposta operacionalizada, encaminhada para quali

				$html .= "<tr>";
					$html .= "<td><b>$record->ID_LSTN</b></td>";
					$html .= "<td><b>$record->CPF_PPNT</b></td>";
					$html .= "<td><b>".utf8_decode($record->NOME_USUA)."</b></td>";
					$html .= "<td><b>$record->VALORCOMPRA_PPST</b></td>";
					$html .= "<td><b>$record->VLENTRADA_PPNT</b></td>";
					$html .= "<td><b>$record->VALORFGTS_PPST</b></td>";
					$html .= "<td><b>$record->VLSINAL_PPNT</b></td>";
					$html .= "<td><b>$record->VLFINSOL_PPNT</b></td>";
					$html .= "<td><b>$record->VLPRESTAPROV_PPNT</b></td>";
					$html .= "<td><b>$record->PRZFINSOL_PPNT</b></td>";
					$html .= "<td><b>" . $this->dateFormat($record->DATA_PPST) . "</b></td>";
					$html .= "<td><b>$recebimentoDocumentacaoAvaliacao</b></td>";
					$html .= "<td><b>$solicitacaoAvaliacao</b></td>";
					$html .= "<td><b>$envioEmail2ContatoValorAvaliacao</b></td>";
					$html .= "<td><b>$recebimentoDocumentacao2Fase</b></td>";
					$html .= "<td><b>$envioAnaliseJuridica</b></td>";
					$html .= "<td><b>$recebimentoDocumentacaoFaltante</b></td>";
					$html .= "<td><b>$dataApto</b></td>";
					$html .= "<td><b>$operacionalizacaoProposta</b></td>";
					$html .= "<td><b>" . $this->dateFormat($record->DTAPROVACAO_IMOV) . "</b></td>";
					$html .= "<td><b>" . $this->dateFormat($record->DTAPROVACAO_PPST) . "</b></td>";
					$html .= "<td><b>" . $this->dateFormat($record->DTASSCONTRATO_PPST) . "</b></td>"; //VALIDAR SE É ESSE CAMPO MESMO
				$html .= "</tr>";

			}
		}

		$html .= '</table>';

		// Configurações header para forçar o download
		header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
		header ("Cache-Control: no-cache, must-revalidate");
		header ("Pragma: no-cache");
		header ("Content-type: application/x-msexcel");
		header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
		header ("Content-Description: PHP Generated Data" );
		// Envia o conteúdo do arquivo
		echo $html;
		exit;
	}

	public function getHistorico($id_proposta, $id_motivo)
	{

		$records = DB::table('proposta')
			->join('historico', 'proposta.COD_PPST', '=', 'historico.COD_PPST')
			->where('proposta.COD_PPST', $id_proposta)
			->where('historico.motivo', $id_motivo)
			->select('historico.DT_HIST')
//			->limit(2) //usado para testar localmente
			->get();

		$datas = [];
		if ( $records ) {

			foreach ( $records as $record ) {

				if ( $record->DT_HIST != null ) {
					$data = Carbon::parse($record->DT_HIST)->format('d/m/Y');
					array_push($datas, $data);
				}
			}
		}

		$parse_datas = '';
		if ( !empty( $datas ) ) {
			$parse_datas = implode(', ', $datas);
		}

		return $parse_datas;
	}

	public function dateFormat($date)
	{
		if (!isset($date) || empty($date)) {
			return "";
		}

		return Carbon::parse($date)->format('d/m/Y');
	}
}
