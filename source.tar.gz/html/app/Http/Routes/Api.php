<?php

namespace App\Http\Routes;

use Illuminate\Contracts\Routing\Registrar;

class Api
{
    /**
     * @param \Illuminate\Contracts\Routing\Registrar $router
     */
    public function map(Registrar $router)
    {
    }
}
