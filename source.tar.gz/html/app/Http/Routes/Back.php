<?php

namespace App\Http\Routes;

use Illuminate\Contracts\Routing\Registrar;

class Back
{
    /**
     * @param \Illuminate\Contracts\Routing\Registrar $router
     */
    public function map(Registrar $router)
    {
        $router->group(['prefix' => 'back', 'middleware' => ['web', 'auth']], function (Registrar $router) {

            $router->get('/', 'DashboardController@index');

            $router->group(['prefix' => 'system', 'namespace' => 'System'], function (Registrar $router) {
                $router->get('/', ['as' => 'back.system', 'uses' => 'DashboardController@index']);

				$router->resource('users', 'UsersController');

				$router->get('/propostas', ['as' => 'back.system', 'uses' => 'PropostasController@index']);
				$router->get('/proposta/{id}/historico', ['as' => 'back.system', 'uses' => 'PropostasController@exibirHistorico']);
				$router->get('/proposta/{id}/documentos', ['as' => 'back.system', 'uses' => 'PropostasController@exibirDocumentos']);
				$router->get('/proposta/exportar', ['as' => 'back.system', 'uses' => 'PropostasController@exibirDocumentos']);
            });

        });
    }
}
