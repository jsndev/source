<?php

namespace App\Services\Products;

use App\Models\Product;
use Illuminate\Support\Facades\Validator;

class EditProduct
{
    /**
     * @var array
     */
    private $rules = [
        'title' => 'required|max:255',
        'price' => 'required|max:255',
        'description' => 'required',
    ];

    /**
     * @param array $data
     * @return mixed
     */
    public function isValid($id, array $data)
    {
        $this->rules['email'] = sprintf($this->rules['email'], $id);

        return Validator::make($data, $this->rules);
    }

    /**
     * @param $id
     * @param array $data
     * @return bool
     */
    public function execute($id, array $data)
    {
        $product = Product::find($id);

        $product->title = $data['title'];
        $product->description = $data['description'];
        $product->price = $data['price'];

        if ($product->save()) {
            return $product;
        }

        return false;
    }
}