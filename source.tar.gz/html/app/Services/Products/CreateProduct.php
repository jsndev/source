<?php

namespace App\Services\Products;

use App\Models\Product;
use Illuminate\Support\Facades\Validator;

class CreateProduct
{
    /**
     * @var array
     */
    private $rules = [
        'title' => 'required|max:255',
        'price' => 'required|max:255',
        'description' => 'required',
    ];

    /**
     * @param array $data
     * @return mixed
     */
    public function isValid(array $data)
    {
        return Validator::make($data, $this->rules);
    }

    /**
     * @param array $data
     * @return bool
     */
    public function execute(array $data)
    {
        if (!$this->isValid($data)) {
            return false;
        }

        $product = new Product();
        $product->title = $data['title'];
        $product->description = $data['description'];
        $product->price = $data['price'];

        if ($product->save()) {

            return $product;
        }

        return false;
    }
}