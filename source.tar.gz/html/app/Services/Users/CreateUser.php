<?php

namespace App\Services\Users;

use App\Events\Users\UserWasCreated;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class CreateUser
{
    /**
     * @var array
     */
    private $rules = [
        'name' => 'required|max:255',
        'cpf' => 'required|max:11|unique:users',
        'email' => 'required|Email|max:255|unique:users',
        'password' => 'required|min:6|confirmed',
    ];

    /**
     * @param array $data
     * @return mixed
     */
    public function isValid(array $data)
    {
        return Validator::make($data, $this->rules);
    }

    /**
     * @param array $data
     * @return bool
     */
    public function execute(array $data)
    {
        if (!$this->isValid($data)) {
            return false;
        }

        $usuarioExistente = DB::table('users')
            ->where('users.email', $data['email'])
            ->first();

		if (!empty($usuarioExistente)) {
			event(new UserWasCreated($usuarioExistente));
			return $usuarioExistente;
		}

        $user = new User();
        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->cpf = $data['cpf'];
		$user->profile = 'proponente'; //usuario que se cadastrar inicialmente sera do perfil proponente, para administadores é necessário alterar manualmente
        $user->password = bcrypt($data['password']);

        if ($user->save()) {
            event(new UserWasCreated($user));

            return $user;
        }

        return false;
    }
}