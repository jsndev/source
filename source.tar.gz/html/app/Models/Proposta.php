<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Proposta extends Model
{
    protected $table = 'proposta';

    const _SITUACAO_ = [
        0 => "Situação Inexistente",
        1 => "Intenção de Proposta",
        2 => "Montagem de Pasta",
        3 => "Avaliação e Análise Documental",
        4 => "Análise Jurídica",
        5 => "Análise Documental",
        6 => "Proposta Aprovada",
        7 => "Assinatura Agendada",
        8 => "Contrato Emitido",
        9 => "Registro de Imóvel",
        10 => "Parecer Final",
        11 => "Finalizada"
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        '*',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];
}
